package clashroyale.core;

public interface Walkable {
    public Position attackCardsWalkable(ClashRoyale game, Position p);
     int step = 1;

}